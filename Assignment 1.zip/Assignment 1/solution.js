//based off a function I accidentally found while looking
//up syntax for higher level functions here: 
//https://eloquentjavascript.net/05_higher_order.html
//takes an array and a filter function and returns an array of 
//all members of the first array that return true for the test.
function filter(data, test) {
  const filteredArray = [];
  for (let candidate of data) {
    if (test(candidate)) {
      filteredArray.push(candidate);          
    }
  }
  return filteredArray;
}

//returns the last instance in the incoming array
//for which test returns true.
function findLast(data, test) {
  let response = {};
  for (index in data) {
    if (test(data[data.length - 1 - index])){
        return data[data.length -1 -index];
    }
  }  
  return null;
}

//maps a transform onto a dataset, returning an array where
//responseArray[x]=transform(data[x])
function map(data, transform) {
  const responseArray = [];
  for (element of data){
    responseArray.push(transform(element));
  }
  return responseArray;
}

//returns an array of tuples in which [x,y] is a member if 
//test(dataset1[x], dataset2[y]) is true.
function pairIf(dataset1, dataset2, test) {
  const response = [];
  for (let member of dataset1){ 
    for (let candidate of dataset2){
      if (test(member, candidate)){
        response.push([member, candidate]);
      }
    }
  }
  return response;
}

//applies reducer to each member of data in sequence, starting with 
//initialValue.
function reduce(data, reducer, initialValue) {
  let accumulatedValue = initialValue;
  for (let member of data) {
    accumulatedValue = reducer(member, accumulatedValue);
  }
  return accumulatedValue;
}

//console.log("total transactions: " + transactions.length);
console.log("Number of invalid transaction: " + (filter(transactions, (candidate)=> {
  return !(candidate.amount && (candidate.product === 
    "FIG_JAM" || "FIG_JELLY" || "SPICY_FIG_JAM" || "ORANGE_FIG_JELLY"))})).length);

console.log("Number of duplicate customers: " + pairIf(customers, customers, (x, y) => {
  return x.id !== y.id && x.firstName === y.firstName && 
      x.lastName === y.lastName && x.email === y.email;
}).length/2);

console.log("Most recent transaction over $200: $" + findLast(transactions, (candidate) => {
  return candidate.amount > 200;
}).amount);

console.log("Number of small transactions: "+ filter(transactions, (candidate)=>{
  return candidate.amount < 25;
}).length);

console.log("Number of medium transaction: "+ filter(transactions, (candidate)=>{
  return candidate.amount >= 25 && candidate.amount <= 75;
}).length);

console.log("Number of large transactions: "+ filter(transactions, (candidate)=>{
  return candidate.amount > 75;
}).length);

const highSpenders = (function(){
  const filteredFunction = filter(transactions, (candidate)=> {
    return candidate.amount > 200;
  });
  
  const pairedFunctions = pairIf(filteredFunction, customers, (transaction, customer)=>{
    return transaction.id === customer.id;
  });
  
  const customerSet = [];
  for (const member of pairedFunctions){
    customerSet.push(member[1]);
  }

  return reduce(customerSet, (customer, uniqueArray)=> {
    if(!(uniqueArray.includes(customer))) {
      uniqueArray.push(customer);
    }
    return uniqueArray;
  }, []);
} )();

console.log("Customers with transactions over $200: "+ highSpenders);

console.log("Names of customers with transactions over $200: " + map(highSpenders, (customer)=> {
  return customer.firstName + " " +customer.lastName;
}));