const madlibsOutput = document.getElementById("mad-libs-output");
const madlibsButton = document.getElementById("mad-libs-button");

function outputToDiv () { 
  madlibsOutput.innerHTML = confirmInputs;
}

madlibsButton.addEventListener("click", () => madlibsOutput.innerHTML = confirmInputs());

const mortgageOut = document.getElementById("mortgage-output");
function outputMortgage(){
  mortgageOut.innerHTML = checkMortgageValues();
}

document.getElementById("loan").addEventListener("blur", outputMortgage);
document.getElementById("interest").addEventListener("blur", outputMortgage);
document.getElementById("num-years").addEventListener("blur", outputMortgage);

outputMortgage();