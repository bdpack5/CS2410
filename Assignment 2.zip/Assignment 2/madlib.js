function buildMadlib (name, place, verb, adjective, object) {
  return `
  One ${adjective} day, ${name} got up. stretched, and went <br>
  downstairs to start ${verb} their ${object}. Then, ${name} heard <br>
  on the radio that there was a bulk sale on ${object} at ${place}. <br>
  But, the day was getting more ${adjective} by the minute, so <br>
  ${name} decided to finish ${verb} the ${object} and go to bed.
  `;
}

const nameIn = document.getElementById("proper-name");
const placeIn = document.getElementById("place");
const verbIn = document.getElementById("verb");
const adjectiveIn = document.getElementById("adjective");
const objectIn = document.getElementById("object");

function confirmInputs(){
  if(!nameIn.value){
    return "You must enter a proper name.";
  }
  if(!placeIn.value){
    return "You must enter a place name.";
  }
  if(!verbIn.value){
    return "You must enter a verb.";
  }
  if(!adjectiveIn.value){
    return "You must enter an adjective.";
  }
  if(!objectIn.value){
    return "You must enter an object.";
  }
  return buildMadlib(nameIn.value, placeIn.value, 
                      verbIn.value, adjectiveIn.value, objectIn.value);
}
