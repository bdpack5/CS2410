const loanAmount = document.getElementById("loan");
const yearlyRate = document.getElementById("interest");
const years = document.getElementById("num-years");

function calculateMortgage (principal, monthlyRate, monthsLeft){
  const x = Math.pow(1+monthlyRate, monthsLeft);
  return principal*monthlyRate*x/(x-1);
}

function checkValues(inputField, defaultVal){
  const myVal = parseFloat(inputField.value);
  if(Number.isNaN(myVal)){
    inputField.value = defaultVal;
    return defaultVal;
  }
  else {
    return myVal;
  }
}

function checkMortgageValues() {
  const principal = checkValues(loanAmount, 100000);
  const monthlyRate = checkValues(yearlyRate, 8)/1200;
  const monthsLeft = checkValues(years, 15)*12;

  return calculateMortgage(principal, monthlyRate, monthsLeft).toFixed(2);
}